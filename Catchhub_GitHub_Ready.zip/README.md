# Catchub Landing Page

A responsive HTML/CSS recreation of the Catchub landing page.

## Files

- `index.html` — page structure and content
- `style.css` — responsive styling
- `images/` — original Catchub assets

## Run locally

Simply double-click `index.html` or open it in your browser.

## Upload to GitHub

1. Create a new repository on GitHub.
2. Upload `index.html`.
3. Upload `style.css`.
4. Upload the entire `images` folder.
5. Commit the changes.
6. In GitHub, open **Settings → Pages**.
7. Under **Build and deployment**, choose **Deploy from a branch**.
8. Select your main branch and `/ (root)`.
9. Save.

Your GitHub Pages site will then be available at your GitHub Pages URL.

## Important

The Android/iOS buttons currently use `#` links. Replace those `href="#"` values in `index.html` with the actual Google Play Store and Apple App Store URLs when you have them.

The Contact Us link currently uses a placeholder email. Replace `contact@example.com` with the real Catchub contact email.
